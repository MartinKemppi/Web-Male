const flag = document.querySelector('.language-selector');
const dropdown = document.querySelector('.dropdown');
const flagOptions = document.querySelectorAll('.flag-option');
const userIcon = document.querySelector('.user-icon');
const userDropdown = document.querySelector('.user-dropdown-menu');
const username = document.querySelector('#username-login-value').textContent;

const translations = {
    ee: {
        title: "Male",
        profile: "Profiil",
        logout: "Logi välja",
        alertMessage: "Status-7: Login peab sisaldama ainult a-Z ilma tühikuteta ja parool peab olema ilma tühikuteta! \n" +
        "Status-8: See nimi on juba hõivatud!",
        profileTitle: "Kasutaja profiil",
        login: "Login:",
        password: "Parool:",
        newLogin: "Uus Login:",
        newPassword: "Uus Parool:",
        newElo: "Uus ELO:",
        save: "Salvesta",
        cancel: "Tühista",
        edit: "Redigeeri",
        whatsElo: "Elo koefitsient, maletaja või kabetaja mängutugevust väljendav näitarv"
    },
    ru: {
        title: "Шахматы",
        profile: "Профиль",
        logout: "Выйти",
        alertMessage: "Status-7: Login peab sisaldama ainult a-Z ilma tühikuteta ja parool peab olema ilma tühikuteta! \n" +
            "Status-8: Это имя уже занято!",
        profileTitle: "Профиль пользователя",
        login: "Логин:",
        password: "Пароль:",
        newLogin: "Новый Логин:",
        newPassword: "Новый Пароль:",
        newElo: "Новый ELO:",
        save: "Сохранить",
        cancel: "Отменить",
        edit: "Редактировать",
        whatsElo: "Коэффициент Эло - цифра, указывающая на силу шахматиста или его игры."
    },
    us: {
        title: "Chess",
        profile: "Profile",
        logout: "Log out",
        alertMessage: "Status-7: Login must contain only a-z without spaces, and the password must not contain spaces! \n" +
            "Status-8: That name is already taken!",
        profileTitle: "User Profile",
        login: "Login:",
        password: "Password:",
        newLogin: "New Login:",
        newPassword: "New Password:",
        newElo: "New ELO:",
        save: "Save",
        cancel: "Cancel",
        edit: "Edit",
        whatsElo: "Elo coefficient, a figure indicating the strength of a chess player or a chess player's game."
    }
};

let currentLang = 'ee';

flag.addEventListener('click', function() {
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
});

userIcon.addEventListener('click', function() {
    userDropdown.style.display = userDropdown.style.display === 'block' ? 'none' : 'block';
});

flagOptions.forEach(flagOption => {
    flagOption.addEventListener('click', function() {
        const lang = flagOption.getAttribute('data-lang');
        currentLang = lang;
        updateLanguage();
    });
});

function updateLanguage() {
    document.querySelector('.header div').textContent = translations[currentLang].title;
    document.querySelector('.profile-container h2').textContent = translations[currentLang].profileTitle;
    document.querySelector('#username-login').textContent = translations[currentLang].login +' '+ username;
    document.querySelector('#username-password').innerHTML = `<strong>${translations[currentLang].password}</strong> <span id="username-password-value">**********</span>`;
    document.querySelector('#new-username-login').textContent = translations[currentLang].newLogin;
    document.querySelector('#new-username-password').textContent = translations[currentLang].newPassword;
    document.querySelector('#new-username-elo').textContent = translations[currentLang].newElo;
    document.querySelector('.save-btn').textContent = translations[currentLang].save;
    document.querySelector('.cancel-btn').textContent = translations[currentLang].cancel;
    document.querySelector('.edit-btn').textContent = translations[currentLang].edit;

    const profileLink = document.getElementById('profile-link');
    if (profileLink) profileLink.textContent = translations[currentLang].profile;

    const logoutButton = document.getElementById('logout-button');
    if (logoutButton) logoutButton.textContent = translations[currentLang].logout;

    const selectedFlag = flag.querySelector('.flag');
    selectedFlag.style.backgroundImage = flagOptions[currentLang === 'ee' ? 0 : currentLang === 'ru' ? 1 : 2].style.backgroundImage;
}

updateLanguage();

function enableEdit() {
    document.getElementById("edit-form").style.display = "block";
    document.getElementById("edit-button").style.display = "none";
}

function cancelEdit() {
    document.getElementById("edit-form").style.display = "none";
    document.getElementById("edit-button").style.display = "block";
}

document.getElementById('male').addEventListener('click', function() {
    window.location.href = 'mainpage.php';
});

function showAlert() {
    alert(translations[currentLang].alertMessage);
}

function  showWhatsElo() {
    alert(translations[currentLang].whatsElo)
}