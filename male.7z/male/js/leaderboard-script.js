const flag = document.querySelector('.language-selector');
const dropdown = document.querySelector('.dropdown');
const flagOptions = document.querySelectorAll('.flag-option');
const userIcon = document.querySelector('.user-icon');
const userDropdown = document.querySelector('.user-dropdown-menu');

const translations = {
    ee: {
        title: "Male",
        profile: "Profiil",
        logout: "Logi välja",
        authenticate: "Autentifitseerimine",
        leaderboard: "EDETABEL",
        username: "Kasutaja",
        whatsElo: "Elo koefitsient, maletaja või kabetaja mängutugevust väljendav näitarv"
    },
    ru: {
        title: "Шахматы",
        profile: "Профиль",
        logout: "Выйти",
        authenticate: "Аутентификация",
        leaderboard: "ТАБЛИЦА ЛИДЕРОВ",
        username: "Пользователь",
        whatsElo: "Коэффициент Эло - цифра, указывающая на силу шахматиста или его игры."
    },
    us: {
        title: "Chess",
        profile: "Profile",
        logout: "Log out",
        authenticate: "Authenticate",
        leaderboard: "LEADERBOARD",
        username: "Username",
        whatsElo: "Elo coefficient, a figure indicating the strength of a chess player or a chess player's game."
    }
};

let currentLang = 'ee';

flag.addEventListener('click', function() {
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
});

userIcon.addEventListener('click', function() {
    userDropdown.style.display = userDropdown.style.display === 'block' ? 'none' : 'block';
});

flagOptions.forEach(flagOption => {
    flagOption.addEventListener('click', function() {
        const lang = flagOption.getAttribute('data-lang');
        currentLang = lang;
        updateLanguage();
    });
});

function updateLanguage() {
    document.querySelector('.header div').textContent = translations[currentLang].title;
    document.querySelector('.leaderboard h2').textContent = translations[currentLang].leaderboard;
    document.querySelector('#leaderboard-username').textContent = translations[currentLang].username;

    const profileLink = document.getElementById('profile-link');
    if (profileLink) profileLink.textContent = translations[currentLang].profile;

    const logoutButton = document.getElementById('logout-button');
    if (logoutButton) logoutButton.textContent = translations[currentLang].logout;

    const authLink = document.getElementById('auth-link');
    if (authLink) authLink.textContent = translations[currentLang].authenticate;

    const selectedFlag = flag.querySelector('.flag');
    selectedFlag.style.backgroundImage = flagOptions[currentLang === 'ee' ? 0 : currentLang === 'ru' ? 1 : 2].style.backgroundImage;
}

updateLanguage();

document.getElementById('male').addEventListener('click', function() {
    window.location.href = 'mainpage.php';
});

function  showWhatsElo() {
    alert(translations[currentLang].whatsElo)
}