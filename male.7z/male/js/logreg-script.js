const registerForm = document.querySelector('.register-form');
const loginForm = document.querySelector('.login-form');
const switchButtons = document.querySelectorAll('.switch-button');
const flag = document.querySelector('.language-selector');
const dropdown = document.querySelector('.dropdown');
const flagOptions = document.querySelectorAll('.flag-option');
const maleText = document.getElementById('male');

function toggleForms() {
    if (registerForm.style.display === 'none') {
        registerForm.style.display = 'block';
        loginForm.style.display = 'none';
    } else {
        registerForm.style.display = 'none';
        loginForm.style.display = 'block';
    }
}

switchButtons.forEach(button => {
    button.addEventListener('click', function() {
        toggleForms();
    });
});

const translations = {
    ee: {
        title: "Male",
        register: "Registreeri",
        login: "Logi sisse",
        username: "Kasutajanimi",
        password: "Parool",
        registerBtn: "Registreeri",
        loginBtn: "Logi sisse",
        switchToLogin: "Mul on olemas konto. Logi sisse",
        switchToRegister: "Mul pole konto. Registreeri",
        alertMessage: "Staatus-1: Registreerimine õnnestus! \n" +
            "Status-2: Kasutajat ei leitud! \n" +
            "Status-3: Vale parool! \n" +
            "Status-4: Registreerimisviga \n" +
            "Status-5: Selle nimega kasutaja on juba olemas! \n" +
            "Status-6: Login peab sisaldama ainult a-Z ilma tühikuteta ja parool peab olema ilma tühikuteta."
    },
    ru: {
        title: "Шахматы",
        register: "Регистрация",
        login: "Войти",
        username: "Имя пользователя",
        password: "Пароль",
        registerBtn: "Зарегистрироваться",
        loginBtn: "Войти",
        switchToLogin: "Уже есть аккаунт. Войти",
        switchToRegister: "Нет аккаунта. Зарегистрироваться",
        alertMessage: "Status-1: Регистрация успешна! \n" +
            "Status-2: Пользователь не найден! \n" +
            "Status-3: Неверный пароль! \n" +
            "Status-4: Ошибка регистрации \n" +
            "Status-5: Пользователь с таким именем уже существует! \n" +
            "Status-6: Логин должен содержать только a-Z без пробелов и пароль должен быть без пробелов"
    },
    us: {
        title: "Chess",
        register: "Register",
        login: "Login",
        username: "Username",
        password: "Password",
        registerBtn: "Register",
        loginBtn: "Login",
        switchToLogin: "Already have an account? Log in",
        switchToRegister: "Don't have an account? Register",
        alertMessage: "Status-1: Registration successful! \n" +
            "Status-2: User not found! \n" +
            "Status-3: Invalid password! \n" +
            "Status-4: Registration error \n" +
            "Status-5: User with this name already exists! \n" +
            "Status-6: Login must contain only a-Z without spaces and password must be without spaces"
    }
};

let currentLang = 'ee';

flag.addEventListener('click', function() {
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
});

flagOptions.forEach(flagOption => {
    flagOption.addEventListener('click', function() {
        const lang = flagOption.getAttribute('data-lang');
        currentLang = lang;
        updateLanguage();
    });
});

function updateLanguage() {
    document.querySelector('.header div').textContent = translations[currentLang].title;
    maleText.textContent = translations[currentLang].title;
    document.querySelector('h2').textContent = translations[currentLang].register;
    document.querySelector('label[for="register-username"]').textContent = translations[currentLang].username;
    document.querySelector('label[for="register-password"]').textContent = translations[currentLang].password;
    document.querySelector('button[type="submit"]').textContent = translations[currentLang].registerBtn;
    document.querySelector('.switch-button').textContent = translations[currentLang].switchToLogin;
    
    document.querySelector('.login-form h2').textContent = translations[currentLang].login;
    document.querySelector('label[for="login-username"]').textContent = translations[currentLang].username;
    document.querySelector('label[for="login-password"]').textContent = translations[currentLang].password;
    document.querySelector('.login-form button[type="submit"]').textContent = translations[currentLang].loginBtn;
    document.querySelector('.login-form .switch-button').textContent = translations[currentLang].switchToRegister;
    
    const selectedFlag = flag.querySelector('.flag');
    selectedFlag.style.backgroundImage = flagOptions[currentLang === 'ee' ? 0 : currentLang === 'ru' ? 1 : 2].style.backgroundImage;
}

updateLanguage();

document.getElementById('male').addEventListener('click', function() {
    window.location.href = 'mainpage.php';
});

function showAlert() {
    alert(translations[currentLang].alertMessage);
}