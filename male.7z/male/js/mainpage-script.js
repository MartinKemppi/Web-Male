const flag = document.querySelector('.language-selector');
const dropdown = document.querySelector('.dropdown');
const flagOptions = document.querySelectorAll('.flag-option');
const userIcon = document.querySelector('.user-icon');
const userDropdown = document.querySelector('.user-dropdown-menu');

const translations = {
    ee: {
        title: "Male",
        playChess: "Alusta male mängu",
        tutorial: "Juhend",
        profile: "Profiil",
        logout: "Logi välja",
        authenticate: "Autentifitseerimine",
        leaderboard: "Edetabel"
    },
    ru: {
        title: "Шахматы",
        playChess: "Начать игру в шахматы",
        tutorial: "Руководство",
        profile: "Профиль",
        logout: "Выйти",
        authenticate: "Аутентификация",
        leaderboard: "Таблица лидеров"
    },
    us: {
        title: "Chess",
        playChess: "Start playing chess",
        tutorial: "Guide",
        profile: "Profile",
        logout: "Log out",
        authenticate: "Authenticate",
        leaderboard: "Leaderboard"
    }
};

let currentLang = 'ee';

flag.addEventListener('click', function() {
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
});

userIcon.addEventListener('click', function() {
    userDropdown.style.display = userDropdown.style.display === 'block' ? 'none' : 'block';
});

flagOptions.forEach(flagOption => {
    flagOption.addEventListener('click', function() {
        const lang = flagOption.getAttribute('data-lang');
        currentLang = lang;
        updateLanguage();
    });
});

function updateLanguage() {
    document.querySelector('.header div').textContent = translations[currentLang].title;
    document.getElementById('play-chess').textContent = translations[currentLang].playChess;
    document.getElementById('tutorial').textContent = translations[currentLang].tutorial;

    const profileLink = document.getElementById('profile-link');
    if (profileLink) profileLink.textContent = translations[currentLang].profile;

    const logoutButton = document.getElementById('logout-button');
    if (logoutButton) logoutButton.textContent = translations[currentLang].logout;

    const authLink = document.getElementById('auth-link');
    if (authLink) authLink.textContent = translations[currentLang].authenticate;

    document.getElementById('leaderboard').textContent = translations[currentLang].leaderboard;

    const selectedFlag = flag.querySelector('.flag');
    selectedFlag.style.backgroundImage = flagOptions[currentLang === 'ee' ? 0 : currentLang === 'ru' ? 1 : 2].style.backgroundImage;
}

updateLanguage();

document.getElementById('chess-image').addEventListener('click', function() {
    window.location.href = 'game.php';
});
document.getElementById('play-chess').addEventListener('click', function() {
    window.location.href = 'game.php';
});
document.getElementById('tutorial').addEventListener('click', function() {
    window.location.href = 'tutorial.php';
});
document.getElementById('leaderboard').addEventListener('click', function() {
    window.location.href = 'leaderboard.php';
});
