const board = document.getElementById("chessboard");
const promotionDiv = document.getElementById("promotion");
const turnIndicator = document.getElementById("turnIndicator");
let selectedCell = null;
let lastMove = {piece: '', fromRow: -1, fromCol: -1, toRow: -1, toCol: -1};
let promotionCell = null;
let isWhiteTurn = true;
let checkPosition = null;
let whiteKingMoved = false;
let blackKingMoved = false;
let whiteRooksMoved = { a: false, h: false };
let blackRooksMoved = { a: false, h: false };
let gameEnded = false;
const winPopup = document.getElementById("winPopup");
const winMessage = document.getElementById("winMessage");

const initialSetup = [
    ['♜','♞','♝','♛','♚','♝','♞','♜'],
    ['♟','♟','♟','♟','♟','♟','♟','♟'],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['♙','♙','♙','♙','♙','♙','♙','♙'],
    ['♖','♘','♗','♕','♔','♗','♘','♖']
];

function createBoard() {
    isWhiteTurn = true;
    winPopup.style.display = "none";
    gameEnded = false;
    board.innerHTML = "";
    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            let cell = document.createElement("div");
            cell.classList.add("cell", (row + col) % 2 === 0 ? "white" : "black");
            cell.textContent = initialSetup[row][col];
            cell.dataset.row = row;
            cell.dataset.col = col;
            cell.addEventListener("click", handleCellClick);
            board.appendChild(cell);
        }
    }
    updateTurnIndicator();
}

function updateTurnIndicator() {
    turnIndicator.textContent = isWhiteTurn ? "♙♗♘♖♕♔" : "♟♝♞♜♛♚";
}

function getBoardState() {
    const state = [];
    for (let row = 0; row < 8; row++) {
        const rowState = [];
        for (let col = 0; col < 8; col++) {
            const cell = board.querySelector(`[data-row="${row}"][data-col="${col}"]`);
            rowState.push(cell.textContent);
        }
        state.push(rowState);
    }
    return JSON.stringify(state);
}

function restoreBoardState(stateStr) {
    const state = JSON.parse(stateStr);
    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            const cell = board.querySelector(`[data-row="${row}"][data-col="${col}"]`);
            cell.textContent = state[row][col];
        }
    }
}

function handleCellClick(event) {
    if (gameEnded) return;

    let cell = event.target;
    if (selectedCell) {
        if (selectedCell !== cell) {
            let fromRow = parseInt(selectedCell.dataset.row);
            let fromCol = parseInt(selectedCell.dataset.col);
            let toRow = parseInt(cell.dataset.row);
            let toCol = parseInt(cell.dataset.col);
            if (isValidMove(selectedCell.textContent, fromRow, fromCol, toRow, toCol)) {
                const currentState = getBoardState();

                const tempFrom = selectedCell.textContent;
                const tempTo = cell.textContent;
                movePiece(selectedCell, cell);

                if (checkVictory(tempTo)) return;

                const isStillCheck = checkForCheck();

                if (checkPosition && isStillCheck && currentState === checkPosition) {
                    restoreBoardState(currentState);
                    return;
                } else {
                    if (!isStillCheck) checkPosition = null;
                    else checkPosition = getBoardState();
                }

                lastMove = {piece: tempFrom, fromRow, fromCol, toRow, toCol};
                selectedCell.textContent = "";
                isWhiteTurn = !isWhiteTurn;
                updateTurnIndicator();
            }
        }
        selectedCell.classList.remove("selected");
        selectedCell = null;
        clearHighlights();
    } else if (cell.textContent !== "" && isPlayerTurn(cell.textContent)) {
        selectedCell = cell;
        selectedCell.classList.add("selected");
        highlightMoves(cell.textContent, parseInt(cell.dataset.row), parseInt(cell.dataset.col));
    }
}

function handleMoveClick(cell) {
    if (gameEnded) return;

    if (selectedCell) {
        let fromRow = parseInt(selectedCell.dataset.row);
        let fromCol = parseInt(selectedCell.dataset.col);
        let toRow = parseInt(cell.dataset.row);
        let toCol = parseInt(cell.dataset.col);
        if (isValidMove(selectedCell.textContent, fromRow, fromCol, toRow, toCol)) {
            if (selectedCell.textContent === '♙' && toRow === 0 ||
                selectedCell.textContent === '♟' && toRow === 7) {
                promotionCell = cell;
                selectedCell.textContent = "";
                promotionDiv.style.display = 'block';
                return;
            }

            if (handleEnPassant(fromRow, fromCol, toRow, toCol)) {
                const capturedPiece = cell.textContent;
                movePiece(selectedCell, cell);
                if (checkVictory(capturedPiece)) return;
                lastMove = {piece: selectedCell.textContent, fromRow, fromCol, toRow, toCol};
                selectedCell.textContent = "";
                isWhiteTurn = !isWhiteTurn;
                updateTurnIndicator();
                return;
            }

            const captured = cell.textContent;
            movePiece(selectedCell, cell);
            if (checkVictory(captured)) return;
            lastMove = {piece: selectedCell.textContent, fromRow, fromCol, toRow, toCol};
            selectedCell.textContent = "";
            selectedCell.classList.remove("selected");
            selectedCell = null;
            isWhiteTurn = !isWhiteTurn;
            clearHighlights();
            updateTurnIndicator();
        }
    }
}

function isPlayerTurn(piece) {
    return (isWhiteTurn && piece.charCodeAt(0) >= 9812 && piece.charCodeAt(0) <= 9817) ||
        (!isWhiteTurn && piece.charCodeAt(0) >= 9818 && piece.charCodeAt(0) <= 9823);
}

function movePiece(fromCell, toCell) {
    const piece = fromCell.textContent;
    const fromRow = parseInt(fromCell.dataset.row);
    const fromCol = parseInt(fromCell.dataset.col);
    const toRow = parseInt(toCell.dataset.row);
    const toCol = parseInt(toCell.dataset.col);
    if ((piece === '♔' || piece === '♚') && Math.abs(toCol - fromCol) === 2) {
        const isWhite = piece === '♔';
        const rookFromCol = toCol === 6 ? 7 : 0;
        const rookToCol = toCol === 6 ? 5 : 3;
        const rookRow = isWhite ? 7 : 0;
        const rook = board.querySelector(`[data-row="${rookRow}"][data-col="${rookFromCol}"]`);
        const rookDest = board.querySelector(`[data-row="${rookRow}"][data-col="${rookToCol}"]`);

        rookDest.textContent = rook.textContent;
        rook.textContent = "";
    }

    toCell.textContent = fromCell.textContent;
    fromCell.textContent = "";

    if (piece === '♔') whiteKingMoved = true;
    if (piece === '♚') blackKingMoved = true;
    if (piece === '♖' && fromRow === 7 && fromCol === 0) whiteRooksMoved.a = true;
    if (piece === '♖' && fromRow === 7 && fromCol === 7) whiteRooksMoved.h = true;
    if (piece === '♜' && fromRow === 0 && fromCol === 0) blackRooksMoved.a = true;
    if (piece === '♜' && fromRow === 0 && fromCol === 7) blackRooksMoved.h = true;

    checkForCheck();
}

function isValidMove(piece, fromRow, fromCol, toRow, toCol) {
    let rowDiff = Math.abs(toRow - fromRow);
    let colDiff = Math.abs(toCol - fromCol);
    let targetCell = board.querySelector(`[data-row="${toRow}"][data-col="${toCol}"]`);
    let isWhite = piece.charCodeAt(0) >= 9812 && piece.charCodeAt(0) <= 9817;
    let isTargetWhite = targetCell.textContent.charCodeAt(0) >= 9812 && targetCell.textContent.charCodeAt(0) <= 9817;
    let isTargetBlack = targetCell.textContent.charCodeAt(0) >= 9818 && targetCell.textContent.charCodeAt(0) <= 9823;

    if (targetCell.textContent !== "" && ((isWhite && isTargetWhite) || (!isWhite && isTargetBlack))) {
        return false;
    }

    switch (piece) {
        case '♙':
            if (fromRow === 6 && fromCol === toCol && toRow === 4 &&
                board.querySelector(`[data-row="5"][data-col="${toCol}"]`).textContent === '' &&
                targetCell.textContent === '') {
                return true;
            }
            if (toRow === fromRow - 1 && fromCol === toCol && targetCell.textContent === '') {
                return true;
            }
            if (toRow === fromRow - 1 && Math.abs(fromCol - toCol) === 1 && targetCell.textContent !== '') {
                return true;
            }
            if (fromRow === 4 && toRow === 5 && Math.abs(fromCol - toCol) === 1) {
                if (lastMove.piece === '♟' && lastMove.fromRow === 6 && lastMove.toRow === 4 && lastMove.toCol === toCol) {
                    return true;
                }
            }
            return false;
        case '♟':
            if (fromRow === 1 && fromCol === toCol && toRow === 3 &&
                board.querySelector(`[data-row="2"][data-col="${toCol}"]`).textContent === '' &&
                targetCell.textContent === '') {
                return true;
            }
            if (toRow === fromRow + 1 && fromCol === toCol && targetCell.textContent === '') {
                return true;
            }
            if (toRow === fromRow + 1 && Math.abs(fromCol - toCol) === 1 && targetCell.textContent !== '') {
                return true;
            }
            if (fromRow === 3 && toRow === 2 && Math.abs(fromCol - toCol) === 1) {
                if (lastMove.piece === '♙' && lastMove.fromRow === 1 && lastMove.toRow === 3 && lastMove.toCol === toCol) {
                    return true;
                }
            }
            return false;
        case '♜':
        case '♖':
            return (fromRow === toRow || fromCol === toCol) && clearPath(fromRow, fromCol, toRow, toCol);
        case '♞':
        case '♘':
            return (rowDiff === 2 && colDiff === 1) || (rowDiff === 1 && colDiff === 2);
        case '♝':
        case '♗':
            return rowDiff === colDiff && clearPath(fromRow, fromCol, toRow, toCol);
        case '♛':
        case '♕':
            return (fromRow === toRow || fromCol === toCol || rowDiff === colDiff) && clearPath(fromRow, fromCol, toRow, toCol);
        case '♚':
            if (!blackKingMoved && fromRow === 0 && fromCol === 4 && toRow === 0 && (toCol === 6 || toCol === 2)) {
                const rookCol = toCol === 6 ? 7 : 0;
                const rook = board.querySelector(`[data-row="0"][data-col="${rookCol}"]`);
                if (rook && rook.textContent === '♜' && !blackRooksMoved[rookCol === 7 ? 'h' : 'a']) {
                    const betweenCols = toCol === 6 ? [5, 6] : [1, 2, 3];
                    if (betweenCols.every(c => board.querySelector(`[data-row="0"][data-col="${c}"]`).textContent === '')) {
                        return true;
                    }
                }
            }
            return rowDiff <= 1 && colDiff <= 1;

        case '♔':
            if (!whiteKingMoved && fromRow === 7 && fromCol === 4 && toRow === 7 && (toCol === 6 || toCol === 2)) {
                const rookCol = toCol === 6 ? 7 : 0;
                const rook = board.querySelector(`[data-row="7"][data-col="${rookCol}"]`);
                if (rook && rook.textContent === '♖' && !whiteRooksMoved[rookCol === 7 ? 'h' : 'a']) {
                    const betweenCols = toCol === 6 ? [5, 6] : [1, 2, 3];
                    if (betweenCols.every(c => board.querySelector(`[data-row="7"][data-col="${c}"]`).textContent === '')) {
                        return true;
                    }
                }
            }
            return rowDiff <= 1 && colDiff <= 1;
        default:
            return false;
    }
}

function clearPath(fromRow, fromCol, toRow, toCol) {
    let rowStep = Math.sign(toRow - fromRow);
    let colStep = Math.sign(toCol - fromCol);
    let r = fromRow + rowStep;
    let c = fromCol + colStep;
    while (r !== toRow || c !== toCol) {
        if (board.querySelector(`[data-row="${r}"][data-col="${c}"]`).textContent !== '') {
            return false;
        }
        r += rowStep;
        c += colStep;
    }
    return true;
}

function highlightMoves(piece, row, col) {
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            if (isValidMove(piece, row, col, r, c)) {
                let cell = document.querySelector(`[data-row="${r}"][data-col="${c}"]`);
                let highlightDiv = document.createElement("div");
                highlightDiv.classList.add("highlight");
                highlightDiv.addEventListener("click", () => handleMoveClick(cell));
                cell.appendChild(highlightDiv);
            }
        }
    }
    if (piece === '♙' && row === 4) {
        checkForEnPassant(row, col, '♟');
    } else if (piece === '♟' && row === 3) {
        checkForEnPassant(row, col, '♙');
    }
}

function checkForEnPassant(row, col, enemyPiece) {
    const lastMovePiece = lastMove.piece;
    const lastMoveFromRow = lastMove.fromRow;
    const lastMoveToRow = lastMove.toRow;
    const lastMoveToCol = lastMove.toCol;

    if (lastMovePiece === enemyPiece && Math.abs(lastMoveFromRow - lastMoveToRow) === 2 && lastMoveToCol === col) {
        const targetRow = (enemyPiece === '♙') ? row - 1 : row + 1;  // Место, куда будет сделан ход на проходе
        const targetCell = document.querySelector(`[data-row="${targetRow}"][data-col="${col}"]`);

        if (targetCell && targetCell.textContent === '') {
            let highlightDiv = document.createElement("div");
            highlightDiv.classList.add("highlight");
            highlightDiv.addEventListener("click", () => handleMoveClick(targetCell));
            targetCell.appendChild(highlightDiv);
        }
    }
}

function clearHighlights() {
    document.querySelectorAll(".highlight").forEach(cell => cell.remove());
}

function promote(piece) {
    promotionCell.textContent = piece;
    promotionCell = null;
    promotionDiv.style.display = 'none';
    isWhiteTurn = !isWhiteTurn;
    updateTurnIndicator();
}

function handleEnPassant(fromRow, fromCol, toRow, toCol) {
    if (selectedCell.textContent === '♙' && fromRow === 4 && toRow === 5 && Math.abs(fromCol - toCol) === 1) {
        if (lastMove.piece === '♟' && lastMove.fromRow === 6 && lastMove.toRow === 4 && lastMove.toCol === toCol) {
            board.querySelector(`[data-row="4"][data-col="${toCol}"]`).textContent = '';
            return true;
        }
    }
    if (selectedCell.textContent === '♟' && fromRow === 3 && toRow === 4 && Math.abs(fromCol - toCol) === 1) {
        if (lastMove.piece === '♙' && lastMove.fromRow === 1 && lastMove.toRow === 3 && lastMove.toCol === toCol) {
            board.querySelector(`[data-row="3"][data-col="${toCol}"]`).textContent = '';
            return true;
        }
    }

    return false;
}

createBoard();



let isCheck = false;
let checkKingCell = null;

function checkForCheck() {
    const whiteKingPosition = findKingPosition(true);
    const blackKingPosition = findKingPosition(false);

    if (!whiteKingPosition || !blackKingPosition) {
        isCheck = false;
        removeCheckHighlight();
        return;
    }

    const whiteOpponentMoves = getAllOpponentMoves(false);
    const blackOpponentMoves = getAllOpponentMoves(true);

    for (const move of blackOpponentMoves) {
        if (move.row === whiteKingPosition.row && move.col === whiteKingPosition.col) {
            isCheck = true;
            highlightCheck(whiteKingPosition);
            return;
        }
    }

    for (const move of whiteOpponentMoves) {
        if (move.row === blackKingPosition.row && move.col === blackKingPosition.col) {
            isCheck = true;
            highlightCheck(blackKingPosition);
            return;
        }
    }

    isCheck = false;
    removeCheckHighlight();
}

function findKingPosition(isWhite) {
    const king = isWhite ? '♔' : '♚';
    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            const cell = board.querySelector(`[data-row="${row}"][data-col="${col}"]`);
            if (cell.textContent === king) {
                return {row, col};
            }
        }
    }
}

function getAllOpponentMoves(isWhite) {
    let moves = [];
    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            const cell = board.querySelector(`[data-row="${row}"][data-col="${col}"]`);
            if (cell.textContent !== "" && isOpponentPiece(cell.textContent, isWhite)) {
                moves = moves.concat(getValidMovesForPiece(cell.textContent, row, col));
            }
        }
    }
    return moves;
}

function isOpponentPiece(piece, isWhite) {
    return (isWhite && piece.charCodeAt(0) >= 9818) || (!isWhite && piece.charCodeAt(0) <= 9817);
}

function getValidMovesForPiece(piece, row, col) {
    let validMoves = [];
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            if (isValidMove(piece, row, col, r, c)) {
                validMoves.push({ row: r, col: c });
            }
        }
    }
    return validMoves;
}

function highlightCheck(kingPosition) {
    checkKingCell = board.querySelector(`[data-row="${kingPosition.row}"][data-col="${kingPosition.col}"]`);
    checkKingCell.style.backgroundColor = 'red';
}

function removeCheckHighlight() {
    if (checkKingCell) {
        checkKingCell.style.backgroundColor = '';
        checkKingCell = null;
    }
}

function checkVictory(capturedPiece) {
    if (capturedPiece === '♚' || capturedPiece === '♔') {
        winMessage.textContent = capturedPiece === '♚' ? "🏆♙♗♘♖♕♔🏆" : "🏆♟♝♞♜♛♚🏆";
        winPopup.style.display = "block";
        gameEnded = true;
        return true;
    }
    return false;
}