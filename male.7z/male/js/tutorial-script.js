const flag = document.querySelector('.language-selector');
const dropdown = document.querySelector('.dropdown');
const flagOptions = document.querySelectorAll('.flag-option');
const sidePanel = document.getElementById('side-panel');
const scrollUpBtn = document.getElementById('scroll-up-btn');
let currentLang = 'ee';

const translations = {
    ee: {
        title: "Male",
        setup: "Algasetus",
        pawn: "♟ETTUR♙",        
        bishop: "♝ODA♗",
        knight: "♞RATSU♘",
        rook: "♜VANKER♖",
        queen: "♛LIPP♕",
        king: "♚KUNINGAS♔",
        nav_pawn_text_item: "♟ETTUR♙",
        nav_bishop_text_item: "♝ODA♗",
        nav_knight_text_item: "♞RATSU♘",
        nav_rook_text_item: "♜VANKER♖",
        nav_queen_text_item: "♛LIPP♕",
        nav_king_text_item: "♚KUNINGAS♔",
        nav_setup_text: "Algasetus",
        nav_pieces_text: "Malendid",
        nav_pawn_text: "Malendite käigud",
        nav_castling_text: "Vangerdus",
        nav_checkmate: "Matt",
        nav_stalemate: "Patt",
        nav_check_text: "Tuli",
        unique_move_text: "UNIKAALSED KÄIGUD",
        promote_move_description_text: "ARENDAMISE SELETUS",
        promote_move_details: "Kui ettur saab viimasele ruudule, saab seda arendama vastava värviga malenditele: ♝♗|♞♘|♜♖|♛♕",
        enpassant_text: "EN PASSANT",
        enpassant_move_description_text: "EN PASSANT SELETUS",
        enpassant_details: "Kui algseisus asuv ettur käib edasi kahe välja võrra, läbides seejuures vastase etturi tulejoones asuva välja, võib vastane oma etturiga selle etturi oma järgmisel käigul lüüa, nagu oleks ettur käinud edasi vaid ühe välja võrra.",
        castling_text: "VANGERDUS",
        castling_move_description_text: "VANGERDUSE SELETUS",
        castling_details: "Vangerdusel käib kuningas algseisust kahe välja võrra vasakule või paremale ja vanker tõstetakse üle kuninga naaberväljale. Alati alustatakse vangerdust kuningaga, sest vankriga alustamist võidakse lugeda lihtsalt vankrikäiguna. Vangerdus on võimalik, kui:<ol><li>1. kuningas ega vanker ei ole partii kestel teinud veel ühtegi käiku;</li><li>2. väljad kuninga ja vankri vahel on vabad;</li><li>3. kuningas ei tohi olla tules, läbida tule all olevat välja ega jääda tule alla. (Vanker võib olla tules ja läbida tule all olevat välja.)</li></ol>",
        check_text: "TULI",
        check_move_description_text: "TULI SELETUS",
        check_details: "Kui vastaspoole malend ründab kuningat, siis öeldakse, et kuningas on tule all. Tule all olev mängija peab oma kuninga ohutusse kohta viima, või tooma vahele oma malendeid. Keelatud on teha käiku, mis jätab või asetab kuninga tule alla.",
        checkmate_text_black_wins: "MATT - MUSTAD VÕIDAVAD",
        checkmate_points_text: "MATT - VALGED VÕIDAVAD, MALENDITE EDEMUS",
        stalemate_text: "PATT - MUSTADEL POLE KÄIKU",
        dead_stalemate_text: "PATT - POLE VÕIMALUST ARENDAMA",
        pieces_text_item: "Malendid"   
    },
    ru: {
        title: "Шахматы",
        setup: "Стартовая позиция",
        pawn: "♟ПЕШКА♙",
        bishop: "♝СЛОН♗",
        knight: "♞КОНЬ♘",
        rook: "♜ЛАДЬЯ♖",
        queen: "♛ФЕРЗЬ♕",
        king: "♚КОРОЛЬ♔",
        nav_pawn_text_item: "♟ПЕШКА♙",
        nav_bishop_text_item: "♝СЛОН♗",
        nav_knight_text_item: "♞КОНЬ♘",
        nav_rook_text_item: "♜ЛАДЬЯ♖",
        nav_queen_text_item: "♛ФЕРЗЬ♕",
        nav_king_text_item: "♚КОРОЛЬ♔",
        nav_setup_text: "Стартовая позиция",
        nav_pieces_text: "Фигуры",
        nav_pawn_text: "Ходы фигур",
        nav_checkmate: "Мат",
        nav_stalemate: "Пат",
        nav_castling_text: "Рокировка",
        nav_check_text: "Шах",
        unique_move_text: "УНИКАЛЬНЫЕ ХОДЫ",
        promote_move_description_text: "ОБЪЯСНЕНИЕ ПРОДВИЖЕНИЯ",
        promote_move_details: "Если пешка достигает последней клетки, она может быть превращена в фигуру соответствующего цвета: ♝♗|♞♘|♜♖|♛♕",
        enpassant_text: "ЭН ПАССАН",
        enpassant_move_description_text: "ОБЪЯСНЕНИЕ ЭН ПАССАН",
        enpassant_details: "Если пешка, находящаяся на начальной позиции, проходит вперед на две клетки, при этом проходя мимо вражеской пешки, то противник может побить эту пешку своим следующим ходом, как если бы она прошла только на одну клетку.",
        castling_text: "РОКИРОВКА",
        castling_move_description_text: "ОБЪЯСНЕНИЕ РОКАДЫ",
        castling_details: "При рокировке король перемещается на две клетки влево или вправо, а ладья перемещается через соседнюю клетку короля. Рокировка всегда начинается с короля, так как начинать с ладьи может быть расценено как просто ход ладьей. Рокировка возможна, если:<ol><li>1. король и ладья не сделали ни одного хода в партии;</li><li>2. клетки между королем и ладьей свободны;</li><li>3. король не должен находиться под шахом, проходить через клетку под шахом или оставаться под шахом. (Ладья может находиться под шахом и проходить через клетку под шахом.)</li></ol>",
        check_text: "ШАХ",
        check_move_description_text: "ОБЪЯСНЕНИЕ ШАХА",
        check_details: "Если фигура противника угрожает королю, то говорят, что король находится под шахом. Игрок, находящийся под шахом, должен переместить своего короля в безопасное место или поставить свою фигуру между королем и угрожающей фигурой. Запрещено делать ход, который оставляет или ставит короля под шахом.",
        checkmate_text_black_wins: "МАТ - ЧЕРНЫЕ ПОБЕЖДАЮТ",
        checkmate_points_text: "МАТ - БЕЛЫЕ ПОБЕЖДАЮТ, ПРЕИМУЩЕСТВО ФИГУР",
        stalemate_text: "ПАТ - НЕТ ХОДОВ У ЧЕРНЫХ",
        dead_stalemate_text: "ПАТ - НЕТ ВОЗМОЖНОСТИ ПРОДВИЖЕНИЯ",
        pieces_text_item: "Фигуры"
    },
    us: {
        title: "Chess",
        setup: "Initial position",
        pawn: "♟PAWN♙",
        bishop: "♝BISHOP♗",
        knight: "♞KNIGHT♘",
        rook: "♜ROOK♖",
        queen: "♛QUEEN♕",
        king: "♚KING♔",
        nav_pawn_text_item: "♟PAWN♙",
        nav_bishop_text_item: "♝BISHOP♗",
        nav_knight_text_item: "♞KNIGHT♘",
        nav_rook_text_item: "♜ROOK♖",
        nav_queen_text_item: "♛QUEEN♕",
        nav_king_text_item: "♚KING♔",
        nav_setup_text: "Initial position",
        nav_pieces_text: "Pieces",
        nav_pawn_text: "Pieces movements",
        nav_castling_text: "Castling",
        nav_checkmate: "Checkmate",
        nav_stalemate: "Stalemate",
        nav_check_text: "Check",
        unique_move_text: "UNIQUE MOVES",
        promote_move_description_text: "PROMOTION EXPLANATION",
        promote_move_details: "When a pawn reaches the last square, it can be promoted to a piece of the corresponding color: ♝♗|♞♘|♜♖|♛♕",
        enpassant_text: "EN PASSANT",
        enpassant_move_description_text: "EN PASSANT EXPLANATION",
        enpassant_details: "If a pawn on its starting position moves forward two squares, passing an enemy pawn on its way, the opponent can capture that pawn on their next turn as if it had moved forward only one square.",
        castling_text: "CASTLING",
        castling_move_description_text: "CASTLING EXPLANATION",
        castling_details: "In castling, the king moves two squares to the left or right, and the rook is moved over to the square next to the king. Castling always starts with the king, as starting with the rook may be considered just a rook move. Castling is possible if:<ol><li>1. the king and rook have not moved during the game;</li><li>2. the squares between the king and rook are unoccupied;</li><li>3. the king cannot be in check, move through a square that is in check, or remain in check. (The rook can be in check and move through a square that is in check.)</li></ol>",
        check_text: "CHECK",
        check_move_description_text: "CHECK EXPLANATION",
        check_details: "If an opponent's piece attacks the king, it is said that the king is in check. The player in check must move their king to a safe square or bring one of their pieces in between. It is illegal to make a move that leaves or places the king in check.",
        checkmate_text_black_wins: "CHECKMATE - BLACK WINS",
        checkmate_points_text: "CHECKMATE - WHITE WINS, PIECE ADVANTAGE",
        stalemate_text: "STALEMATE - NO MOVES FOR BLACK",
        dead_stalemate_text: "STALEMATE - NO POSSIBILITY TO PROMOTE",
        pieces_text_item: "Pieces"
    }
};

flag.addEventListener('click', function() {
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
});

flagOptions.forEach(flagOption => {
    flagOption.addEventListener('click', function() {
        const lang = flagOption.getAttribute('data-lang');
        currentLang = lang;
        updateLanguage();
    });
});

function updateLanguage() {
    document.getElementById('male').textContent = translations[currentLang].title;
    document.getElementById('setup-text').textContent = translations[currentLang].setup;
    document.getElementById('pawn-text').textContent = translations[currentLang].pawn;
    document.getElementById('bishop-text').textContent = translations[currentLang].bishop;
    document.getElementById('knight-text').textContent = translations[currentLang].knight;
    document.getElementById('rook-text').textContent = translations[currentLang].rook;
    document.getElementById('queen-text').textContent = translations[currentLang].queen;
    document.getElementById('king-text').textContent = translations[currentLang].king;
    document.getElementById('nav-setup-text').textContent = translations[currentLang].nav_setup_text;
    document.getElementById('nav-pieces-text').textContent = translations[currentLang].nav_pieces_text;
    document.getElementById('nav-pawn-text').textContent = translations[currentLang].nav_pawn_text;
    document.getElementById('nav-castling-text').textContent = translations[currentLang].nav_castling_text;
    document.getElementById('nav-checkmate').textContent = translations[currentLang].nav_checkmate;
    document.getElementById('nav-stalemate').textContent = translations[currentLang].nav_stalemate;
    document.getElementById('nav-check-text').textContent = translations[currentLang].nav_check_text;
    document.getElementById('unique-move-text').textContent = translations[currentLang].unique_move_text;
    document.getElementById('promote-move-description-text').textContent = translations[currentLang].promote_move_description_text;
    document.getElementById('promotion-text').innerHTML = translations[currentLang].promote_move_details;
    document.getElementById('enpassant-text').textContent = translations[currentLang].enpassant_text;
    document.getElementById('enpassant-move-description-text').textContent = translations[currentLang].enpassant_move_description_text;
    document.getElementById('enpssant-move-description-text').innerHTML = translations[currentLang].enpassant_details;
    document.getElementById('castling-text').textContent = translations[currentLang].castling_text;
    document.getElementById('castling-move-description-text').textContent = translations[currentLang].castling_move_description_text;
    document.getElementById('castling-move-description-text').innerHTML = translations[currentLang].castling_details;
    document.getElementById('check-text').textContent = translations[currentLang].check_text;
    document.getElementById('check-move-description-text').textContent = translations[currentLang].check_move_description_text;
    document.getElementById('check-description-text').innerHTML = translations[currentLang].check_details;
    document.getElementById('checkmate-points-text').textContent = translations[currentLang].checkmate_points_text;
    document.getElementById('checkmate-text').textContent = translations[currentLang].checkmate_text_black_wins;
    document.getElementById('stalemate-text').textContent = translations[currentLang].stalemate_text;
    document.getElementById('dead-stalemate-text').textContent = translations[currentLang].dead_stalemate_text;
    document.getElementById('pieces-text-item').textContent = translations[currentLang].pieces_text_item;
    document.getElementById('nav-pawn-text-item').textContent = translations[currentLang].nav_pawn_text_item;
    document.getElementById('nav-bishop-text-item').textContent = translations[currentLang].nav_bishop_text_item;
    document.getElementById('nav-knight-text-item').textContent = translations[currentLang].nav_knight_text_item;
    document.getElementById('nav-rook-text-item').textContent = translations[currentLang].nav_rook_text_item;
    document.getElementById('nav-queen-text-item').textContent = translations[currentLang].nav_queen_text_item;
    document.getElementById('nav-king-text-item').textContent = translations[currentLang].nav_king_text_item;

    const selectedFlag = flag.querySelector('.flag');
    selectedFlag.style.backgroundImage = flagOptions[currentLang === 'ee' ? 0 : currentLang === 'ru' ? 1 : 2].style.backgroundImage;
}

updateLanguage();

document.getElementById('male').addEventListener('click', function() {
    window.location.href = 'mainpage.php';
});

window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        sidePanel.style.display = 'block';
    } else {
        sidePanel.style.display = 'none';
    }

    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 10) {
        sidePanel.classList.add('at-bottom');
    } else {
        sidePanel.classList.remove('at-bottom');
    }
});

scrollUpBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

document.addEventListener('DOMContentLoaded', function () {
    const hamburgerIcon = document.getElementById('hamburger-icon');
    const navLinks = document.querySelector('.nav-links');

    hamburgerIcon.addEventListener('click', function () {
        navLinks.classList.toggle('active');
    });

    hamburgerIcon.addEventListener('dblclick', function () {
        navLinks.classList.remove('active');
    });
});