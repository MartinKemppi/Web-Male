<?php
session_start();
require_once 'functions.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['register'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $message = registerUser($username, $password);
    } elseif (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $result = loginUser($username, $password);

        if ($result === "pass") {
            $_SESSION['username'] = $username;
            header("Location: mainpage.php");
            exit;
        } else {
            $message = $result;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="et">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logi sisse/Registreerimine</title>
    <link rel="icon" type="image/x-icon" href="pic/favicon.png">
    <link rel="stylesheet" href="css/logreg-style.css">
    <script src="js/logreg-script.js" defer></script>
</head>
<body>
<div class="header">
    <div id="male">Male</div>
    <div class="language-selector">
        <div class="flag" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/8/8f/Flag_of_Estonia.svg');"></div>
        <div class="dropdown">
            <div class="flag-option" data-lang="ee" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/8/8f/Flag_of_Estonia.svg');"></div>
            <div class="flag-option" data-lang="ru" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/f/f3/Flag_of_Russia.svg');"></div>
            <div class="flag-option" data-lang="us" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a4/Flag_of_the_United_States.svg');"></div>
        </div>
    </div>
</div>
<div class="auth-container">
    <?php if ($message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>
    <div class="auth-form register-form">
        <h2>Registreeri</h2>
        <form method="POST" action="">
            <label for="register-username">Kasutajanimi</label>
            <input type="text" id="register-username" name="username" placeholder="Sisesta kasutajanimi" required>

            <label for="register-password">Parool</label>
            <input type="password" id="register-password" name="password" placeholder="Sisesta parool" required>

            <button type="submit" name="register">Registreeri</button>
        </form>
        <button class="switch-button">Logi sisse oma kontoga</button>
    </div>
    <div class="auth-form login-form" style="display: none;">
        <h2>Logi sisse</h2>
        <form method="POST" action="">
            <label for="login-username">Kasutajanimi</label>
            <input type="text" id="login-username" name="username" placeholder="Sisesta kasutajanimi" required>

            <label for="login-password">Parool</label>
            <input type="password" id="login-password" name="password" placeholder="Sisesta parool" required>

            <button type="submit" name="login">Logi sisse</button>
        </form>
        <button class="switch-button">Registreeri uue konto</button>
    </div>
</div>
<button class="circle-button" onclick="showAlert()">?</button>
<div class="footer">
    © Martin Kemppi 2025
</div>
</body>
</html>
