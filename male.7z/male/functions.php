<?php
//require_once 'conf.php';
require_once 'conf2.php';

function registerUser($username, $password) {
    global $yhendus;

    if (!preg_match('/^[a-zA-Z]+$/', $username)) {
        return "Status-6";
    }

    if (preg_match('/\s/', $password)) {
        return "Status-6";
    }

    $stmt = $yhendus->prepare("SELECT username FROM dbuser WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        return "Status-5";
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $yhendus->prepare("INSERT INTO dbuser (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $hashedPassword);

    if ($stmt->execute()) {
        return "Status-1";
    } else {
        return "Status-4: " . $stmt->error;
    }
}

function loginUser($username, $password) {
    global $yhendus;

    $stmt = $yhendus->prepare("SELECT password FROM dbuser WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        return "Status-2";
    }

    $stmt->bind_result($hashedPassword);
    $stmt->fetch();

    if (password_verify($password, $hashedPassword)) {
        return "pass";
    } else {
        return "Status-3";
    }
}

function updateUser($currentUsername, $newUsername, $newPassword, $newElo) {
    global $yhendus;

    if (!preg_match('/^[a-zA-Z]+$/', $newUsername)) {
        return "Status-7";
    }

    if (preg_match('/\s/', $newPassword)) {
        return "Status-7";
    }

    if (!ctype_digit($newElo) || $newElo < 0) {
        return "Status-7";
    }

    if ($newUsername !== $currentUsername) {
        $stmt = $yhendus->prepare("SELECT username FROM dbuser WHERE username = ?");
        $stmt->bind_param("s", $newUsername);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            return "Status-8";
        }

        $stmt->close();
    }

    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    if ($newUsername === $currentUsername) {
        $stmt = $yhendus->prepare("UPDATE dbuser SET password=?, elo=? WHERE username=?");
        $stmt->bind_param("sis", $hashedPassword, $newElo, $currentUsername);
    } else {
        $stmt = $yhendus->prepare("UPDATE dbuser SET username=?, password=?, elo=? WHERE username=?");
        $stmt->bind_param("ssis", $newUsername, $hashedPassword, $newElo, $currentUsername);
    }

    if ($stmt->execute()) {
        return "success";
    } else {
        return "Status-4: " . $stmt->error;
    }
}

function getUserElo($username) {
    global $yhendus;

    $stmt = $yhendus->prepare("SELECT elo FROM dbuser WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($elo);
    $stmt->fetch();
    $stmt->close();

    return $elo;
}

function leaderboards() {
    global $yhendus;

    $stmt = $yhendus->prepare("SELECT username, elo FROM dbuser ORDER BY elo DESC");
    $stmt->execute();

    $leaderboard = [];

    $stmt->bind_result($username, $elo);
    while ($stmt->fetch()) {
        $leaderboard[] = ['username' => $username, 'elo' => $elo];
    }
    $stmt->close();

    return $leaderboard;
}
?>
