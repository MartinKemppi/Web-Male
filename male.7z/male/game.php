<!DOCTYPE html>
<html lang="et">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Malemäng</title>
    <link rel="icon" type="image/x-icon" href="pic/favicon.png">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/script.js" defer></script>
</head>
<body>
<div class="board" id="chessboard"></div>
<div class="promotion" id="promotion">
    <button onclick="promote('♕')">♕</button>
    <button onclick="promote('♖')">♖</button>
    <button onclick="promote('♘')">♘</button>
    <button onclick="promote('♗')">♗</button>
</div>
<div class="turn-indicator" id="turnIndicator"></div>
<button class="reset-btn" onclick="createBoard()">♻</button>
<div class="win-popup" id="winPopup">
    <div id="winMessage">🏆♔🏆</div>
</div>
</body>
</html>