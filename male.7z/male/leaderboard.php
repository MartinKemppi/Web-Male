<?php
session_start();

include "functions.php";

$leaderboard = leaderboards();
?>
<!DOCTYPE html>
<html lang="et">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edetabel</title>
    <link rel="icon" type="image/x-icon" href="pic/favicon.png">
    <link rel="stylesheet" href="css/leaderboard-style.css">
    <script src="js/leaderboard-script.js" defer></script>
</head>
<body>
<div class="header">
    <div id="male">Male</div>
    <div class="user-dropdown">
        <div class="user-icon" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/9/9a/System-users-3.svg');">
            <div class="user-dropdown-menu">
                <?php if (isset($_SESSION['username'])): ?>
                    <span id="user-info">♟<?php echo htmlspecialchars($_SESSION['username']); ?>♙</span>
                    <a href="profile.php" class="dropdown-item" id="profile-link">Profiil</a>
                    <a href="logout.php" class="dropdown-item" id="logout-button">Logi välja</a>
                <?php else: ?>
                    <a href="index.php" class="dropdown-item" id="auth-link">Autentifitseerimine</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="language-selector">
        <div class="flag" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/8/8f/Flag_of_Estonia.svg');"></div>
        <div class="dropdown">
            <div class="flag-option" data-lang="ee" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/8/8f/Flag_of_Estonia.svg');"></div>
            <div class="flag-option" data-lang="ru" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/f/f3/Flag_of_Russia.svg');"></div>
            <div class="flag-option" data-lang="us" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a4/Flag_of_the_United_States.svg');"></div>
        </div>
    </div>
</div>
<div class="leaderboard">
    <h2>EDETABEL</h2>
    <table>
        <thead>
        <tr>
            <th>#</th>
            <th id="leaderboard-username">Kasutaja</th>
            <th onclick="showWhatsElo()">ELO</th>
        </tr>
        </thead>
        <tbody>
        <?php if (!empty($leaderboard)): ?>
            <?php $position = 1; ?>
            <?php foreach ($leaderboard as $player): ?>
                <tr>
                    <td><?php echo $position++; ?></td>
                    <td><?php echo htmlspecialchars($player['username']); ?></td>
                    <td onclick="showWhatsElo()"><?php echo htmlspecialchars($player['elo']); ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="3">NaN</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="footer">
    © Martin Kemppi 2025
</div>
</body>
</html>