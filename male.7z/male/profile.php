<?php
session_start();
require_once 'functions.php';

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['username'];
$elo = getUserElo($username);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUsername = $_POST['username'];
    $newPassword = $_POST['password'];
    $newElo = $_POST['elo'];

    $status = updateUser($username, $newUsername, $newPassword, $newElo);

    if ($status === 'success') {
        $_SESSION['username'] = $newUsername;
        $username = $newUsername;
        $elo = $newElo;
    } else {
        $errorMessage = $status;
    }
}
?>
<!DOCTYPE html>
<html lang="et">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profiil</title>
    <link rel="icon" type="image/x-icon" href="pic/favicon.png">
    <link rel="stylesheet" href="css/profile-style.css">
    <script src="js/profile-script.js" defer></script>
</head>
<body>
<div class="header">
    <div id="male">Male</div>
    <div class="user-dropdown">
        <div class="user-icon" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/9/9a/System-users-3.svg');">
            <div class="user-dropdown-menu">
                <?php if (isset($_SESSION['username'])): ?>
                    <span id="user-info">♟<?php echo htmlspecialchars($_SESSION['username']); ?>♙</span>
                    <a href="profile.php" class="dropdown-item" id="profile-link">Profiil</a>
                    <a href="logout.php" class="dropdown-item" id="logout-button">Logi välja</a>
                <?php else: ?>
                    <a href="index.php" class="dropdown-item" id="auth-link">Autentifitseerimine</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="language-selector">
        <div class="flag" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/8/8f/Flag_of_Estonia.svg');"></div>
        <div class="dropdown">
            <div class="flag-option" data-lang="ee" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/8/8f/Flag_of_Estonia.svg');"></div>
            <div class="flag-option" data-lang="ru" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/f/f3/Flag_of_Russia.svg');"></div>
            <div class="flag-option" data-lang="us" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a4/Flag_of_the_United_States.svg');"></div>
        </div>
    </div>
</div>
<div class="content">
    <div class="profile-container">
        <h2>Kasutaja profiil</h2>
        <p id="username-login"><strong>Login:</strong> <span id="username-login-value"><?php echo htmlspecialchars($username); ?></span></p>
        <p id="username-password"><strong>Parool:</strong> <span id="username-password-value">**********</span></p>
        <p onclick="showWhatsElo()"><strong>ELO:</strong> <span id="elo-text"><?php echo htmlspecialchars($elo ?? 'Pole määratud'); ?></span></p>

        <?php if (isset($errorMessage)): ?>
            <div style="color: red; text-align: center;"><?php echo htmlspecialchars($errorMessage); ?></div>
        <?php endif; ?>

        <form id="edit-form" method="POST">
            <label id="new-username-login">Uus Login:</label>
            <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" required>

            <label id="new-username-password">Uus Parool:</label>
            <input type="password" name="password" required>

            <label id="new-username-elo">Uus ELO:</label>
            <input type="number" name="elo" value="<?php echo htmlspecialchars($elo ?? 0); ?>" min="0" required>

            <div class="buttons">
                <button type="submit" class="save-btn">Salvesta</button>
                <button type="button" class="cancel-btn" onclick="cancelEdit()">Tühista</button>
            </div>
        </form>

        <button class="edit-btn" id="edit-button" onclick="enableEdit()">Redigeeri</button>
    </div>
</div>
<button class="circle-button" onclick="showAlert()">?</button>
<div class="footer">
    © Martin Kemppi 2025
</div>
</body>
</html>
