<?php
session_start();
?>

<!DOCTYPE html>
<html lang="et">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pealeht</title>
    <link rel="icon" type="image/x-icon" href="pic/favicon.png">
    <link rel="stylesheet" href="css/mainpage-style.css">
    <script src="js/mainpage-script.js" defer></script>
</head>
<body>
    <div class="header">
        <div>Male</div>
        <div class="user-dropdown">
            <div class="user-icon" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/9/9a/System-users-3.svg');">
                <div class="user-dropdown-menu">
                    <?php if (isset($_SESSION['username'])): ?>
                        <span id="user-info">♟<?php echo htmlspecialchars($_SESSION['username']); ?>♙</span>
                        <a href="profile.php" class="dropdown-item" id="profile-link">Profiil</a>
                        <a href="logout.php" class="dropdown-item" id="logout-button">Logi välja</a>
                    <?php else: ?>
                        <a href="index.php" class="dropdown-item" id="auth-link">Autentifitseerimine</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="language-selector">
            <div class="flag" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/8/8f/Flag_of_Estonia.svg');"></div>
            <div class="dropdown">
                <div class="flag-option" data-lang="ee" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/8/8f/Flag_of_Estonia.svg');"></div>
                <div class="flag-option" data-lang="ru" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/f/f3/Flag_of_Russia.svg');"></div>
                <div class="flag-option" data-lang="us" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a4/Flag_of_the_United_States.svg');"></div>
            </div>
        </div>
    </div>   
    <div class="content">
        <div class="image-container">
            <img id="chess-image" src="pic/chess_pic.png" alt="Chess Image">
        </div>       
        <div class="divs-container">
            <div id="play-chess">Alusta male mängu</div>
            <div id="leaderboard">Edetabel</div>
            <div id="tutorial">Juhend</div>
        </div>
    </div>
    <div class="footer">
        © Martin Kemppi 2025
    </div>
</body>
</html>