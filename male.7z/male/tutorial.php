<!DOCTYPE html>
<html lang="et">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juhend</title>
    <link rel="icon" type="image/x-icon" href="pic/favicon.png">
    <link rel="stylesheet" href="css/tutorial-style.css">
    <script src="js/tutorial-script.js" defer></script>   
</head>
<body>
    <header class="header">
        <div id="male">Male</div>
        <div class="language-selector">
            <div class="flag" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/8/8f/Flag_of_Estonia.svg');"></div>
            <div class="dropdown">
                <div class="flag-option" data-lang="ee" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/8/8f/Flag_of_Estonia.svg');"></div>
                <div class="flag-option" data-lang="ru" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/f/f3/Flag_of_Russia.svg');"></div>
                <div class="flag-option" data-lang="us" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a4/Flag_of_the_United_States.svg');"></div>
            </div>
        </div>
        <div id="hamburger-icon" class="hamburger-icon">
            &#9776;
        </div>
    </header>  
    <main class="content">
        <nav class="nav-links">
            <ul>
                <li><a href="#pieces-text-item" id="nav-pieces-text">Malendid</a></li>    
                <li><a href="#setup-text" id="nav-setup-text">Algasetus</a></li>                
                <li><a href="#pawn-text" id="nav-pawn-text">Malendite käigud</a></li>
                <li><a href="#castling-text" id="nav-castling-text">Vangerdus</a></li>
                <li><a href="#check-text" id="nav-check-text">Tuli</a></li>
                <li><a href="#checkmate-text" id="nav-checkmate">Matt</a></li>
                <li><a href="#stalemate-text" id="nav-stalemate">Patt</a></li>
            </ul>           
        </nav>
        <div class="image-container">
            <div class="pieces-text-item" id="pieces-text-item">Malendid</div>
            <div class="pawn-text-item">
                <a href="#pawn-text" id="nav-pawn-text-item">♟ETTUR♙</a>
            </div>
            <div class="bishop-text-item">
                <a href="#bishop-text" id="nav-bishop-text-item">♝ODA♗</a>
            </div>
            <div class="knight-text-item">
                <a href="#knight-text" id="nav-knight-text-item">♞RATSU♘</a>
            </div>
            <div class="rook-text-item">
                <a href="#rook-text" id="nav-rook-text-item">♜VANKER♖</a>
            </div>
            <div class="queen-text-item">
                <a href="#queen-text" id="nav-queen-text-item">♛LIPP♕</a>
            </div>
            <div class="king-text-item">
                <a href="#king-text" id="nav-king-text-item">♚KUNINGAS♔</a>
            </div>
            <div id="setup-text">Algasetus</div>
            <div class="image-item">
                <img id="board-image" src="pic/board.png" alt="Chess Board">
            </div>
            <div id="pawn-text">♟ETTUR♙</div>
            <div class="image-item">                
                <img id="pawnmove-image" src="pic/pawnmove.png" alt="Pawn Move">
            </div>
            <div id="bishop-text">♝ODA♗</div>
            <div class="image-item">               
                <img id="bishopmove-image" src="pic/bishopmove.png" alt="Bishop Move">
            </div>
            <div id="knight-text">♞RATSU♘</div>
            <div class="image-item">                
                <img id="knightmove-image" src="pic/knightmove.png" alt="Knight Move">
            </div>
            <div id="rook-text">♜VANKER♖</div>
            <div class="image-item">                
                <img id="rookmove-image" src="pic/rookmove.png" alt="Rook Move">
            </div>
            <div id="queen-text">♛LIPP♕</div>
            <div class="image-item">               
                <img id="queenmove-image" src="pic/queenmove.png" alt="Queen Move">
            </div>
            <div id="king-text">♚KUNINGAS♔</div>
            <div class="image-item">               
                <img id="kingmove-image" src="pic/kingmove.png" alt="King Move">
            </div>
            <div id="unique-move-text">UNIKAALSED KÄIGUD</div>
            <div class="image-item">               
                <img id="unique-move-image" src="pic/uniquemoves.gif" alt="Unique moves">
            </div>
            <div id="promote-move-description-text">ARENDAMISE SELETUS</div>
            <div class="image-item">               
                <div id="promotion-text">Kui ettur saab viimasele ruudule, saab seda arendama vastava värviga malenditele: ♝♗|♞♘|♜♖|♛♕</div>
            </div>
            <div id="enpassant-text">EN PASSANT</div>
            <div class="image-item">               
                <img id="enpassant-move-image" src="pic/enpassant.png" alt="En passant move">
            </div>
            <div id="enpassant-move-description-text">EN PASSANT SELETUS</div>
            <div class="image-item">               
                <div id="enpssant-move-description-text">Kui algseisus asuv ettur käib edasi kahe välja võrra, läbides seejuures vastase etturi tulejoones asuva välja, võib vastane oma etturiga selle etturi oma järgmisel käigul lüüa, nagu oleks ettur käinud edasi vaid ühe välja võrra.</div>
            </div>
            <div id="castling-text">VANGERDUS</div>
            <div class="image-item">               
                <img id="castling-move-image" src="pic/castlingmove.gif" alt="Castling move">
            </div>
            <div id="castling-move-description-text">VANGERDUSE SELETUS</div>
            <div id="check-text">TULI</div>
            <div class="image-item">               
                <img id="check-image" src="pic/check.png" alt="Check">
            </div>
            <div id="check-move-description-text">TULI SELETUS</div>
            <div class="image-item">               
                <div id="check-description-text">
                    <ul>
                        <li>Kui vastaspoole malend ründab kuningat, siis öeldakse, et kuningas on tule all.</li>
                        <li>Tule all olev mängija peab oma kuninga ohutusse kohta viima, või tooma vahele oma malendeid.</li>
                        <li>Keelatud on teha käiku, mis jätab või asetab kuninga tule alla.</li>
                    </ul>
                </div>
            </div>
            <div id="checkmate-text">MATT - MUSTAD VÕIDAVAD</div>
            <div class="image-item">               
                <img id="checkmate-image" src="pic/checkmate.png" alt="Checkmate">
            </div>
            <div id="checkmate-points-text">MATT - VALGED VÕIDAVAD, MALENDITE EDEMUS</div>
            <div class="image-item">               
                <img id="checkmate-points-image" src="pic/checkmate-points.png" alt="Checkmate points">
            </div>
            <div id="stalemate-text">PATT - MUSTADEL POLE KÄIKU</div>
            <div class="image-item">               
                <img id="stalemate-image" src="pic/stalemate.png" alt="Stalemate">
            </div>
            <div id="dead-stalemate-text">PATT - POLE VÕIMALUST ARENDAMA</div>
            <div class="image-item">               
                <img id="dead-stalemate-image" src="pic/deadstalemate.png" alt="Dead stalemate">
            </div>             
        </div>
    </main>
    <div id="side-panel" class="side-panel">
        <button id="scroll-up-btn" class="scroll-up-btn">↑</button>
    </div>
    <footer class="footer">
        <span id="footer-text">© Martin Kemppi 2025</span>
    </footer>
</body>
</html>